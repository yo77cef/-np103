sozcuk=input("bir sozcuk giriniz")
harf=input("bir harf girin")
count=0
for karakter in sozcuk:
  if karakter== harf:
      count=count+1
print(count)

