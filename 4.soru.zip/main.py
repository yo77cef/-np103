sozcuk=input("bir sözcük girin")
print(sozcuk[1:])