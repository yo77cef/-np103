sozcuk=input("bir sozcuk giriniz")
for i in sozcuk:
  print(i+"!")
