sozcuk=input("bir sözcük girin")
sozcuk=sozcuk[0]+sozcuk[-1]
print(sozcuk)