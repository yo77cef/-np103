toplam_yumurta = int(input("Kaç yumurta topladınız? "))
karton = toplam_yumurta // 12
print("Bugün", karton, "adet 12'lik yumurta kutusu lazım.")