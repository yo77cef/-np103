sozcuk= input("bir sözcük giriniz")
harf= input("harf girin")
print(sozcuk.replace(harf,""))