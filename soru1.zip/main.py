toplam_yumurta = int(input("Kaç yumurta topladınız? "))
