kahve_turleri = {
    "Espresso": 2.5,
    "Americano": 3,
    "Latte": 2.5,
    "Cappuccino": 3,
    "Macchiato": 2.5,
    "Mocha": 3.5,
    "Flat White": 2.5
}
boyut_fiyatlari = {
    "Orta": 0,
    "Büyük":  1,
    "XL": 1.5
}
yemek_secenegi_fiyat = {
    "İçeride": 0,
    "Dışarıya": 1
}
kahve_secimi = input("Kahve türünü seçin (Espresso, Americano, Latte, Cappuccino,Macchiato,Mocha,Flat White,.): ")
boyut_secimi = input("Fincan boyutunu seçin (Orta, Büyük, XL): ")
yemek_secimi = input("Yemek seçeneğinizi belirtin (İçeride, Dışarıya): ")
kahve_fiyati = kahve_turleri[kahve_secimi]
boyut_fiyati = boyut_fiyatlari[boyut_secimi]
yemek_fiyati = yemek_secenegi_fiyat[yemek_secimi]
toplam_fiyat = kahve_fiyati + boyut_fiyati + yemek_fiyati
print("Toplam Fiyat: " + str(toplam_fiyat) + " TL")
