sozcuk=input("bir kelime gir")
sesli_harfler="AEIİOÖUÜaeıioöuü"
count=0
for karakter in sozcuk:
  for sesli in sesli_harfler:
    if sesli==karakter:
      count=count+1
print(count)
