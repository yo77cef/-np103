my_tuple = (0, 1, 2, "hi", 4, 5)
print("Orijinal tuple:", my_tuple)
temp_list = list(my_tuple)
temp_list[3] = 3  
my_tuple = tuple(temp_list)
print("Yeni tuple:", my_tuple)