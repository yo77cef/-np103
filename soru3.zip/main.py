toplam_yumurta = int(input("Kaç yumurta topladınız? "))
karton = toplam_yumurta // 12
kalan_yumurta = toplam_yumurta % 12
if kalan_yumurta >= 6:
    karton_6lik = 1
    kalan_yumurta -= 6 
else:
    karton_6lik = 0
print("Bugün", karton, "adet 12'lik yumurta kutusu lazım.")
if karton_6lik > 0:
    print("Bir adet 6'lık yumurta kutusuna da ihtiyacınız var.")
else:
    print("6'lık yumurta kutusuna ihtiyacınız yok.")