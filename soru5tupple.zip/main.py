n = int(input("Kaç sayı gireceksiniz? "))
en_buyuk = int(input("1. sayıyı girin: "))
for i in range(1, n):
    sayi = int(input(str(i+1) + ". sayıyı girin: "))
    if sayi > en_buyuk:
        en_buyuk = sayi
print("En büyük sayı:", en_buyuk)