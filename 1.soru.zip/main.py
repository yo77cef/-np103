ad=input("isminizi girin")
soyad=input("soyisminizi girin")
ad_ilk_harf= ad[0]
soyad_ilk_harf=soyad[0]
print(ad_ilk_harf+"."+soyad_ilk_harf".")