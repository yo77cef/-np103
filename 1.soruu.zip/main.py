kelime=input("bir kelime giriniz")
print(len(kelime))