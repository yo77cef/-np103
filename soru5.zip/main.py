sozcuk=input("bir sözcük girin")
sayi=int(input("bir sayı girin"))
ilk_kisim=sozcuk[0:sayi]
son_kisim=sozcuk[sayi:]
print(ilk_kisim+"-"+son_kisim)