
isim = input("İsminizi giriniz: ")
harfler = list(isim)
print(harfler)