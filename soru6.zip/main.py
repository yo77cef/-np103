sozcuk=input("bir sözcük girin")
sayi=int(input("bir sayı girin"))
harf=input("bir harf  girin")
ilk_kisim=sozcuk[0:sayi-1]
son_kisim=sozcuk[sayi:]
print(ilk_kisim+harf+son_kisim)